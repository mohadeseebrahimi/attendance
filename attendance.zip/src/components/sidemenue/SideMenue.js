import { Link } from "react-router-dom";
import { MdAdminPanelSettings } from "react-icons/md";
import { MdOutlineDashboardCustomize } from "react-icons/md";
import { TbReportSearch } from "react-icons/tb";
import { PiChatCenteredTextBold } from "react-icons/pi";
import { MdOutlineLogin } from "react-icons/md";

function SideMenue() {
  return (
    <>
      <div className="container-side">
        <nav>
          <ul className="ull">
            <li>
              <Link to='/' className="logo">
                <MdAdminPanelSettings size="43px" color="#97bf8d" />
                <span className="nav-item">Home</span>
              </Link>
            </li>

            <li>
              <Link to="/dashboard">
                <MdOutlineDashboardCustomize className="icon" />
                <span className="nav-item">Dashboard</span>
              </Link>
            </li>

            <li>
              <Link to="/report">
                <TbReportSearch className="icon" />
                <span className="nav-item">Report</span>
              </Link>
            </li>

            <li>
              <Link to="/attendance">
                <PiChatCenteredTextBold className="icon" />
                <span className="nav-item">Attendance</span>
              </Link>
            </li>

            <li className="logout">
              <Link to="/login">
                <MdOutlineLogin className="icon" />
                <span className="nav-item ">Login</span>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
}

export default SideMenue;
