import SideMenue from "../../components/sidemenue/SideMenue";
import img1 from "../../images/logo1.png";

function Attendance() {
  return (
    <>
      <section className="main">
        <div className="main-top">
          <h1>Attendance</h1>
        </div>
      </section>

      <div className="profile-container">
        <div className="profile-box">
          <img className="profile-pic" src={img1}></img>
          <h3>abas abasi</h3>
          <p>web developer at darik </p>
          <button className="profile-btn">i'm comming</button>
        </div>
        
      </div>

      <SideMenue />
    </>
  );
}

export default Attendance;
