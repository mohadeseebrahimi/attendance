import SideMenue from "../../components/sidemenue/SideMenue";

function Home() {
  return (
    <>
      <section className="main">
        <div className="main-top">
          <h1> Home</h1>
        </div>
      </section>

      <SideMenue />
    </>
  );
}

export default Home;
