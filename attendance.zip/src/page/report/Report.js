import SideMenue from "../../components/sidemenue/SideMenue";

function Report() {
  return (
    <>
      <section className="main">
        <div className="main-top">
          <h1>Report</h1>
        </div>
      </section>

      <SideMenue />
    </>
  );
}

export default Report;
