import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { BrowserRouter , Routes , Route } from "react-router-dom";
import Home from "./page/home/Home";
import Attendance from "./page/attendance/Attendence";
import Dashboard from './page/dashboard/Dashboard'
import Report from "./page/report/Report";
import Login from "./page/login/Login";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <>
  
    <BrowserRouter>
       <Routes>

        <Route path="/" element={<Home />} />
        <Route path="/attendance" element={<Attendance/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/report" element={<Report/>} />
        <Route path="/login" element={<Login/>} />
      
      </Routes>
    </BrowserRouter>
  </>

);
