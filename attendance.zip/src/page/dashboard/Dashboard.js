import SideMenue from "../../components/sidemenue/SideMenue";

function Dashboard() {
  return (
    <>
      <section className="main">
        <div className="main-top">
          <h1>Dashboard</h1>
        </div>
      </section>
      <SideMenue />
    </>
  );
}

export default Dashboard;
