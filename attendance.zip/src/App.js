import Home from "./page/home/Home";
import Login from "./page/login/Login";


function App() {


  return (
    <>
    
    <Home/>
    <Login/>

    </>
  );
}

export default App;
